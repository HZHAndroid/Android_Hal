#define LOG_TAG "HelloStub"

#include <hardware/hardware.h>
#include <fcntl.h>
#include <errno.h>
#include <cutils/log.h>
#include <hardware/helloworld.h>

#define DEVICE_NAME "/dev/XXX"
#define MODULE_NAME "HelloWorld"
#define MODULE_DES "HelloWorld: Implement Add function"
#define MODULE_AUTHOR "11346544@qq.com"

//module open and close function
static int helloworld_open(const struct hw_module_t* module, const char* name, struct hw_device_t** device);
static int helloworld_close(struct hw_device_t* device);

//module function method
static int helloworld_add(struct helloworld_device_t* dev, int a, int b, int* c);

//Module methods list
//typedef struct hw_module_methods_t {
//    /** Open a specific device */
//    int (*open)(const struct hw_module_t* module, const char* id,
//            struct hw_device_t** device);
//} hw_module_methods_t;

static struct hw_module_methods_t helloworld_module_methods = {
	open: helloworld_open
};

//moudle struct
struct helloworld_module_t HAL_MODULE_INFO_SYM = {
	common: {
		tag: HARDWARE_MODULE_TAG,
		version_major: 1,
		version_minor: 0,
		id: HELLOWORLD_HARDWARE_MODULE_ID,
		name: MODULE_NAME,
		author: MODULE_AUTHOR,
		methods: &helloworld_module_methods,
	},
        description:MODULE_DES,
        methodsNum:1,
};


//module open function
static int helloworld_open(const struct hw_module_t* module, const char* name, struct hw_device_t** device) {
        //1: New a helloworld_device_t
	struct helloworld_device_t* dev;
        dev = (struct helloworld_device_t*)malloc(sizeof(struct helloworld_device_t));
	if(!dev) {
		ALOGE("Helloworld open: failed to alloc device space");
		return -EFAULT;
	}

        //2: Set Value to hello_device_t
	memset(dev, 0, sizeof(struct helloworld_device_t));
	dev->common.tag = HARDWARE_DEVICE_TAG;
	dev->common.version = 0;
	dev->common.module = (hw_module_t*)module;//set the moudle
	dev->common.close = helloworld_close;//set the close function
	dev->helloworld_add = helloworld_add;

        //3: open driver file
//	if((dev->fd = open(DEVICE_NAME, O_RDWR)) == -1) {
//		LOGE("Helloworld open: failed to open device driver-- %s.", strerror(errno));
//                free(dev);//free the malloc memory
//		return -EFAULT;
//	}

        
	*device = &(dev->common);
	ALOGI("Helloworld open: open driver file successfully.");
       
	return 0;
}

//module close function
static int helloworld_close(struct hw_device_t* device) {
        //1: device Type change
	struct helloworld_device_t* helloworld_device = (struct helloworld_device_t*)device;

        //2: free the device memory, close driver file
	if(helloworld_device) {
            //close(hello_device->fd);
	    free(helloworld_device);
	}
	
	return 0;
}

static int helloworld_add(struct helloworld_device_t* dev, int a, int b, int* c){
        ALOGI("Helloworld add:  value %d + value %d", a, b);

        *c = a+b;
        //you can operator the driver file by dev->fd
        return 0;
}

