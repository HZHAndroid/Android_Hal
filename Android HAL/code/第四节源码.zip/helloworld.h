#ifndef ANDROID_HELLOWORLD_INTERFACE_H  
#define ANDROID_HELLOWORLD_INTERFACE_H  
#include <hardware/hardware.h>  
  
__BEGIN_DECLS  
  
//定义模块ID
#define HELLOWORLD_HARDWARE_MODULE_ID "helloworld"  
  
//硬件模块结构
/**
 * Every hardware module must have a data structure named HAL_MODULE_INFO_SYM
 * and the fields of this data structure must begin with hw_module_t
 * followed by module specific information.
 */
struct helloworld_module_t {  
    struct hw_module_t common;

    //add some specific information
    char *description;
    int  methodsNum;
};  
  
//硬件接口结构体
/**
 * Every device data structure must begin with hw_device_t
 * followed by module specific public methods and attributes.
 */
struct helloworld_device_t {  
    struct hw_device_t common;  
    int fd;  //can save the driver file
    int (*helloworld_add)(struct helloworld_device_t* dev, int a, int b, int* c);
};  
  
__END_DECLS  
  
#endif  
