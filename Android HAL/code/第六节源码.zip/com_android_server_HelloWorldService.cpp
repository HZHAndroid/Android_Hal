/* //device/libs/android_runtime/android_server_AlarmManagerService.cpp
**
** Copyright 2006, The Android Open Source Project
**
** Licensed under the Apache License, Version 2.0 (the "License");
** you may not use this file except in compliance with the License.
** You may obtain a copy of the License at
**
**     http://www.apache.org/licenses/LICENSE-2.0
**
** Unless required by applicable law or agreed to in writing, software
** distributed under the License is distributed on an "AS IS" BASIS,
** WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
** See the License for the specific language governing permissions and
** limitations under the License.
*/

#define LOG_TAG "HelloworldService"

#include "JNIHelp.h"
#include "jni.h"  
#include "JNIHelp.h"  
#include "android_runtime/AndroidRuntime.h"  
#include <utils/misc.h>  
#include <utils/Log.h>  
#include <hardware/hardware.h>  
#include <hardware/helloworld.h>  
#include <stdio.h> 

namespace android {

 struct helloworld_device_t* helloworld_device = NULL;  

static jint helloworld_AddVal(JNIEnv* env, jobject clazz, jint a, jint b) { 
        int result;
        ALOGI("HelloWorld JNI: add value %d and %d.", a, b);  
        if(!helloworld_device) {  
            ALOGI("Helloworld JNI: device is not open.");  
            return -1;  
        }  
          
        helloworld_device->helloworld_add(helloworld_device, a, b, &result);  
        return result;
}  


static inline int helloworld_device_open(const hw_module_t* module, struct helloworld_device_t** device) {  
        return module->methods->open(module, HELLOWORLD_HARDWARE_MODULE_ID, (struct hw_device_t**)device);  
}  


static jboolean helloworld_init(JNIEnv* env, jclass clazz) {  
        helloworld_module_t* module;  
          
        ALOGI("Helloworld JNI: initializing......");  
        if(hw_get_module(HELLOWORLD_HARDWARE_MODULE_ID, (const struct hw_module_t**)&module) == 0) {  
            ALOGI("Helloworld JNI: hello Stub found.");  
            if( helloworld_device_open(&(module->common), &helloworld_device) == 0) {  
                ALOGI("Helloworld JNI: hello device is open.");  
                return 0;  
            }  
            ALOGE("Helloworld JNI: failed to open hello device.");  
            return -1;  
        }  
        ALOGE("Helloworld JNI: failed to get hello stub module.");  
        return -1;        
}

static JNINativeMethod sMethods[] = {
	{"init", "()Z", (void*)helloworld_init},
	{"addValue", "(II)I", (void*)helloworld_AddVal},
};

int register_android_server_HelloWorldService(JNIEnv* env)
{
    return jniRegisterNativeMethods(env, "com/android/server/HelloWorldService",
                                    sMethods, NELEM(sMethods));
}

} /* namespace android */
